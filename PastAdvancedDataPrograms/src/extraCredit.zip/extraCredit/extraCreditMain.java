package extraCredit;

public class extraCreditMain {
    public static void main(String[] args) {
        Tree234 t = new Tree234();
        t.insert(40);
        t.insert(50);
        t.insert(70);
        t.insert(35);
        t.insert(60);
        t.insert(10);
        t.displayTree();
    }
}
