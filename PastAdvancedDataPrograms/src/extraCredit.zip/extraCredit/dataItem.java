package extraCredit;

public class dataItem {
    public int dData;

    public dataItem(int data) {
        dData = data;
    }

    public void displayItem() {
        System.out.print(" " + dData);
    }
}
