package Project6;

class Node {
    public Student data;
    public Node leftChild;
    public Node rightChild;
}
